<?php

namespace BPMC;

use Illuminate\Database\Eloquent\Model;

class Member_info extends Model
{
    //
}
