<?php

namespace BPMC;

use Illuminate\Database\Eloquent\Model;

class Photo extends Model
{
    //
}
